<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<script type="text/javascript">
	var link = "http://localhost/error_reporting/index.php/error";
	window.location.href = link;
</script>
