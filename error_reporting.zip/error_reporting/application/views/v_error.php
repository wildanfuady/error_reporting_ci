<!DOCTYPE html>
<html>
<head>
	<title>Halaman Error</title>
</head>
<body>
	<p>Halaman yang Anda cari tidak tersedia!</p>
	<a href="#" onclick="history.go(-1);">Kembali</a>
</body>
</html>